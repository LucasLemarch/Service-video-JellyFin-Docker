#!/bin/bash

jellyfin -w /usr/share/jellyfin/web --datadir /data/